<?php

namespace Unusualify\Modularity\Tests\Traits\HasPriceable;

use Illuminate\Database\Eloquent\Model;
class PriceType extends Model{

    protected $fillable = [
        'name',
    ];

    protected $table = 'price_types';

}
