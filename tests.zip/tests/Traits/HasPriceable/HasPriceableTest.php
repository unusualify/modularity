<?php

namespace Unusualify\Modularity\Tests\Traits\HasPriceable;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Request;
use Unusualify\Modularity\Tests\Traits\HasPriceable;
use Unusualify\Modularity\Tests\TestCase;

class HasPriceableTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Schema::create('currencies', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->integer('iso_4217')->nullable();
            $table->timestamps();
        });

        Schema::create('prices', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('currency_id');
            $table->bigInteger('display_price');
        });

        Schema::create('price_types', function(Blueprint $table){
            $table->bigIncrements('id');
            $table->string('name');
        });

        Schema::create('vat_rates', function(Blueprint $table){
            $table->bigIncrements('id');
            $table->string('name');
            $table->unsignedDouble('rate');
        });



    }




}
