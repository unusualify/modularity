<?php

namespace Unusualify\Modularity\Tests\Traits\HasPriceable;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
class PriceModel extends Model
{
    protected $fillable = [
        'currency_id',
        'display_price'
    ];

    protected $table = 'prices';

    public function currency(): BelongsTo
    {
        return $this->belongsTo(CurrencyModel::class, 'currency_id');
    }

    public function priceable(): MorphTo
    {
        return $this->morphTo();
    }
}
