<?php

namespace Unusualify\Modularity\Tests\Traits\HasPriceable;

use Illuminate\Database\Eloquent\Model;


class VatRateModel extends Model{

    protected $fillable = [
        'name',
        'rate',
    ];

    protected $table = 'vat_rates';
}
