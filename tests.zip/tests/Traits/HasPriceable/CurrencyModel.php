<?php

namespace Unusualify\Modularity\Tests\Traits\HasPriceable;

use Illuminate\Database\Eloquent\Model;


class CurrencyModel extends Model
{
    protected $fillable = [
        'name',
        'iso_4217'
    ];

    protected $table = 'currencies';

}
